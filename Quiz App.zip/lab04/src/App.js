import React from 'react';
import { QuizProvider } from './component/lab04/QuizContext';
import Quiz from './component/lab04/Quiz';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <QuizProvider>
      <Quiz />
    </QuizProvider>
  );
}

export default App;
