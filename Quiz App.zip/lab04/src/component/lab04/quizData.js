

export const quizData = [ 
    { 
        question: "Which hook is used for managing component state in functional components?", 
        answers: ["useState", "useEffect", "useReducer"], 
        correctAnswer: "useState" 
    }, 
    { 
        question: "Which hook is used for handling side effects in a component?", 
        answers: ["useMemo", "useCallback", "useEffect"], 
        correctAnswer: "useEffect" 
    }, 
    { 
        question: "Which hook is used to optimize performance by memoizing the result of a function?", 
        answers: ["useEffect", "useCallback", "useMemo"], 
        correctAnswer: "useMemo" 
    }, 
    { 
        question: "Which hook returns a memoized callback function?", 
        answers: ["useMemo", "useCallback", "useReducer"], 
        correctAnswer: "useCallback" 
    }, 
    { 
        question: "Which hook is used to access context values in a functional component?", 
        answers: ["useState", "useContext", "useEffect"], 
        correctAnswer: "useContext" 
    }, 
    { 
        question: "Which hook helps manage complex state logic in React?", 
        answers: ["useEffect", "useReducer", "useState"], 
        correctAnswer: "useReducer" 
    }, 
    { 
        question: "What will happen if you call a hook inside a conditional statement?", 
        answers: [ 
            "It will cause an error",
                "It will work normally", 
            "It will only work if inside a function" 
        ], 
        correctAnswer: "It will cause an error" 
    }, 
    { 
        question: "Which hook is used to get a reference to a DOM element?", 
        answers: ["useRef", "useEffect", "useState"], 
        correctAnswer: "useRef" 
    }, 
    { 
        question: "Which hook is best for fetching data in a component?", 
        answers: ["useEffect", "useState", "useReducer"], 
        correctAnswer: "useEffect" 
    }, 
    { 
        question: "What does useState return?", 
        answers: [ 
            "A state value and a function to update it", 
            "An array of all state variables", 
            "A function that re-renders the component" 
        ], 
        correctAnswer: "A state value and a function to update it" 
    } 
]; 

 