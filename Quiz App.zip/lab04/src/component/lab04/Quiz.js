import React, { useContext } from 'react';
import { quizData } from './quizData';
import Question from './Question';
import Score from './Score';
import { QuizContext } from './QuizContext';

function Quiz() {
  const { submitted, setSubmitted } = useContext(QuizContext);

  const handleSubmit = () => {
    setSubmitted(true);
  };

  return (
    <div className="container mt-4">
      <h1 className=" mt-4">React Hooks Quiz</h1>
      <Score />

      {quizData.map((q, i) => (
        <Question key={i} index={i} questionData={q} />
      ))}
      {!submitted && (
        <div className="text-center">
          <button className="btn btn-primary mt-3" onClick={handleSubmit}>
            Submit
          </button>
        </div>
      )}
    </div>
  );
}

export default Quiz;
