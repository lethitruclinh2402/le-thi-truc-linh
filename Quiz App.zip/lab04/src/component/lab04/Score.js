import React, { useContext } from 'react';
import { quizData } from './quizData';
import { QuizContext } from './QuizContext';

function Score() {
  const { selectedAnswers, submitted } = useContext(QuizContext);
  if (!submitted) return null;

  const correctCount = quizData.reduce((acc, q, i) => {
    return acc + (selectedAnswers[i] === q.correctAnswer ? 1 : 0);
  }, 0);

  return (
  <div className="alert  fs-4">
  <strong>Score: {correctCount} / {quizData.length}</strong>
</div>

  );
}

export default Score;
