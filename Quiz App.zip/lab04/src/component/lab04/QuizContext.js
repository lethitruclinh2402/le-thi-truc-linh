import React, { createContext, useState } from 'react';

export const QuizContext = createContext();

export const QuizProvider = ({ children }) => {
  const [selectedAnswers, setSelectedAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const updateAnswer = (index, answer) => {
    setSelectedAnswers(prev => ({ ...prev, [index]: answer }));
  };

  return (
    <QuizContext.Provider value={{ selectedAnswers, updateAnswer, submitted, setSubmitted }}>
      {children}
    </QuizContext.Provider>
  );
};
