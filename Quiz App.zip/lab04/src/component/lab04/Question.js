import React, { useContext } from "react";
import { QuizContext } from "./QuizContext";

function Question({ index, questionData }) {
  //initialize useContext
  const { selectedAnswers, updateAnswer, submitted } = useContext(QuizContext);

  return (
    <div className="card mb-3">
      <div className="card-header">
        <strong>Question {index + 1}:</strong> {questionData.question}
     
      </div>
      <div className="card-body">
        {questionData.answers.map((ans, i) => ( 
          <div key={i} className="form-check">
            <input
              className="form-check-input"
              type="radio"
              name={`q-${index}`} 
              value={ans}
              disabled={submitted} 
              checked={selectedAnswers[index] === ans}
              onChange={() => updateAnswer(index, ans)} 
            />
            <label className="form-check-label">{ans}</label>
          </div>
        ))}
        {submitted && (
          <div className="mt-2">
            {selectedAnswers[index] === questionData.correctAnswer 
              ? "✅ Correct"
              : "❌ Incorrect"}
          </div>
        )}
      </div>
    </div>
  );
}

export default Question;
