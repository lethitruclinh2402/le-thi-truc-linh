package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Review;
import utils.DBContext;

public class ReviewDao extends DBContext {

    public List<Review> getAllReviews() {
        List<Review> listReviews = new ArrayList<>();
        String sql = "SELECT "
                + "r.Review_ID, r.User_ID, r.Product_ID, r.Order_ID, r.Rating, r.Comment, r.Review_Date, "
                + "u.Username, p.Product_Name, o.Status as OrderStatus "
                + "FROM Product_Review r "
                + "LEFT JOIN Users u ON r.User_ID = u.User_ID "
                + "LEFT JOIN Product p ON r.Product_ID = p.Product_ID "
                + "LEFT JOIN Orders o ON r.Order_ID = o.Order_ID "
                + "ORDER BY r.Review_Date DESC";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Review review = new Review(
                        rs.getInt("Review_ID"),
                        rs.getInt("User_ID"),
                        rs.getInt("Product_ID"),
                        rs.getInt("Order_ID"),
                        rs.getInt("Rating"),
                        rs.getString("Comment"),
                        rs.getTimestamp("Review_Date"),
                        rs.getString("Username"),
                        rs.getString("Product_Name"),
                        rs.getString("OrderStatus")
                );
                listReviews.add(review);
            }
        } catch (SQLException e) {
            System.out.println("Error getting all reviews: " + e.getMessage());
        }
        return listReviews;
    }

    // Có thể bổ sung thêm các hàm CRUD khác nếu cần
} 