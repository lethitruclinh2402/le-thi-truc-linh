/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Category;
import utils.DBContext;

/**
 *
 * @author ADMIN
 */
public class CategoryDao extends DBContext {

    public CategoryDao() {
        super();
    }

    public List<Category> getAllCategory() {
        List<Category> listCat = new ArrayList<>();
        String sql = "SELECT  \n"
                + "    c.Category_ID, c.Category_Name,\n"
                + "    c.Category_Description, c.Category_Image,\n"
                + "    c.Category_Parent_ID, c.Category_Status,\n"
                + "    c.Created_At, c.Updated_At\n"
                + "FROM \n"
                + "    Category c";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Category cat = new Category(rs.getInt("Category_ID"), rs.getString("Category_Name"),
                        rs.getString("Category_Description"), rs.getInt("Category_Parent_ID"),
                        rs.getString("Category_Image"), rs.getInt("Category_Status"));
                cat.setCreated_At(rs.getString("Created_At"));
                cat.setUpdated_At(rs.getString("Updated_At"));
                listCat.add(cat);
            }

        } catch (SQLException e) {
            System.out.println("Error");
        }
        return listCat;
    }

    public Category getCategoryByID(String ID) {

        String sql = "select * from Category c where c.Category_ID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
             ps.setString(1, ID);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                Category cat = new Category(rs.getInt("Category_ID"), rs.getString("Category_Name"),
                        rs.getString("Category_Description"), rs.getInt("Category_Parent_ID"),
                        rs.getString("Category_Image"), rs.getInt("Category_Status"));
                return cat;
            }

        } catch (SQLException e) {
            System.out.println("Error");
        }
        return null;
    }

    // Thêm category mới với đủ trường
    public void addCategory(String name, String description, Integer parentId, String image, int status) {
        String sql = "INSERT INTO Category (Category_Name, Category_Description, Category_Parent_ID, Category_Image, Category_Status) VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, description);
            if (parentId != null) ps.setInt(3, parentId); else ps.setNull(3, java.sql.Types.INTEGER);
            ps.setString(4, image);
            ps.setInt(5, status);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error addCategory: " + e.getMessage());
        }
    }

    // Sửa category với đủ trường
    public void updateCategory(int id, String name, String description, Integer parentId, String image, int status) {
        String sql = "UPDATE Category SET Category_Name = ?, Category_Description = ?, Category_Parent_ID = ?, Category_Image = ?, Category_Status = ?, Updated_At = GETDATE() WHERE Category_ID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, description);
            if (parentId != null) ps.setInt(3, parentId); else ps.setNull(3, java.sql.Types.INTEGER);
            ps.setString(4, image);
            ps.setInt(5, status);
            ps.setInt(6, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error updateCategory: " + e.getMessage());
        }
    }

    public void updateCategoryStatus(int id, int status) {
        String sql = "UPDATE Category SET Category_Status = ?, Updated_At = GETDATE() WHERE Category_ID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, status);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Xóa category theo ID
    public void deleteCategory(int id) {
        String sql = "DELETE FROM Category WHERE Category_ID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error deleteCategory: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        CategoryDao dao = new CategoryDao();
        System.out.println(dao.getCategoryByID("1").getCat_Name());
        for (Category cat : dao.getAllCategory()) {
            System.out.println(cat.toString());
        }

    }
}
